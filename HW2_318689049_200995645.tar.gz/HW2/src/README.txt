Names: Dror Pezo, Amnon Balanov
E-mails: Drorpezo@campus.technion.ac.il, Samnonb@campus.technion.ac.il
IDs: 318689049, 200995645

How to run the tool:
1) Copy ex2.cpp file to the directory:
/pin-3.7-97619-g0d0c92f4f-gcc-linux/source/tools/ManualExamples

2) Create executable using make:
make ex2.test

3) Run the tool:
../../../pin -t obj-intel64/ex2.so -- <prog>
Where prog is the target program

4) Results should appear in 'loop-count.csv' file


